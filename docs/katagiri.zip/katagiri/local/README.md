# local/ — gitignored

Audio clips, subtitle files, video, screenshots, your recordings, downloaded dictionaries.

Nothing here is committed. Two reasons: most of it isn't yours to redistribute, and the rest is large and regenerable.

Suggested layout:

```
local/
  audio/       tts cache, keyed by content hash
  clips/       mined media clips
  recordings/  your own voice, referenced from reviews.jsonl
  subs/        subtitle files
  dict/        JMdict, KANJIDIC2, pitch data
```
